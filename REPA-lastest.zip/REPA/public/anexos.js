
// public/anexos.js

import { initAnexo5, cargarEmbarcaciones } from './js/anexo5.js';
document.addEventListener('DOMContentLoaded', () => {
    const anexoForm3 = document.getElementById('anexo3-pesca-form');
    const body = document.body;
    const themeToggle = document.getElementById('theme-toggle');
    const openBtn = document.getElementById('sidebar-open-btn');
    const closeBtn = document.getElementById('sidebar-close-btn');
    const overlay = document.getElementById('sidebar-overlay');
    const tabLinks = document.querySelectorAll('.tab-link');
    const tabContents = document.querySelectorAll('.tab-content');
    const sidebarUserName = document.getElementById('sidebar-user-name');
    const logoutBtn = document.getElementById('logout-btn-sidebar');
    const logoutModal = document.getElementById('logout-modal');
    const mainCancelButton = document.getElementById('cancel-anexo-btn');
    const cancelModal = document.getElementById('cancel-confirm-modal');
    const infoModal = document.getElementById('info-modal');
    const infoModalTitle = document.getElementById('info-modal-title');
    const infoModalMessage = document.getElementById('info-modal-message');
    const infoModalIcon = document.getElementById('info-modal-icon');
    const infoModalCloseBtn = document.getElementById('info-modal-close-btn');
    const anexoForm1 = document.getElementById('solicitante-form');
    const addIntegranteForm = document.getElementById('add-integrante-form');
    const integrantesTableBody = document.getElementById('integrantes-table-body');
    const deleteModal = document.getElementById('delete-confirm-modal');
    const editModal = document.getElementById('edit-integrante-modal');
    const editForm = document.getElementById('edit-integrante-form');
    const cancelEditModalBtn = document.getElementById('cancel-edit-modal-btn');
    const anexoForm4 = document.getElementById('anexo4-acuacultura-form');
    let integranteEditId = null;
    let integrantesData = [];
// =======================================================
// == FUNCIONES DE VALIDACIÓN REUTILIZABLES
// =======================================================

/**
 * Valida un campo en tiempo real para que solo acepte números
 * y trunca el valor si excede la longitud máxima.
 * @param {HTMLInputElement} inputElement El campo de input a validar.
 * @param {number} maxLength La cantidad máxima de dígitos permitidos.
 */
const validateNumericInput = (inputElement, maxLength) => {
    // 1. Reemplaza cualquier caracter que NO sea un número por nada (lo elimina)
    inputElement.value = inputElement.value.replace(/[^0-9]/g, '');

    // 2. Si el valor excede la longitud máxima, lo recorta
    if (inputElement.value.length > maxLength) {
        inputElement.value = inputElement.value.slice(0, maxLength);
    }
};

/**
 * Valida un campo en tiempo real para que solo acepte letras (incluyendo acentos, ñ) y espacios.
 * @param {HTMLInputElement} inputElement El campo de input a validar.
 */
const validateTextInput = (inputElement) => {
    // Reemplaza cualquier caracter que NO sea una letra (mayúscula o minúscula, con acentos, ñ) o un espacio.
    inputElement.value = inputElement.value.replace(/[^a-zA-ZáéíóúÁÉÍÓÚñÑ\s]/g, '');
};

const showFeedback = (inputElement, message, isValid) => {
    const feedbackElement = inputElement.nextElementSibling;
    if (feedbackElement && feedbackElement.classList.contains('feedback-message')) {
        inputElement.classList.remove('valid', 'invalid');
        feedbackElement.classList.remove('valid', 'invalid');

        if (message) {
            inputElement.classList.add(isValid ? 'valid' : 'invalid');
            feedbackElement.classList.add(isValid ? 'valid' : 'invalid');
            feedbackElement.textContent = message;
        } else {
            feedbackElement.textContent = '';
        }
    }
};

const isValidRFC = (rfc) => {
    const rfcRegex = /^([A-ZÑ&]{3,4}) ?(?:- ?)?(\d{2}(?:0[1-9]|1[0-2])(?:0[1-9]|[12]\d|3[01])) ?(?:- ?)?([A-Z\d]{2})([A\d])$/;
    return rfcRegex.test(rfc);
};

const isValidCURP = (curp) => {
    const curpRegex = /^[A-Z]{1}[AEIOU]{1}[A-Z]{2}[0-9]{2}(0[1-9]|1[0-2])(0[1-9]|1[0-9]|2[0-9]|3[0-1])[HM]{1}(AS|BC|BS|CC|CS|CH|CL|CM|DF|DG|GT|GR|HG|JC|MC|MN|MS|NT|NL|OC|PL|QT|QR|SP|SL|SR|TC|TS|TL|VZ|YN|ZS|NE)[B-DF-HJ-NP-TV-Z]{3}[0-9A-Z]{1}[0-9]{1}$/;
    return curpRegex.test(curp);
};

/**
 * Valida que una cadena de texto tenga el formato de un correo electrónico válido.
 * @param {string} email El correo a validar.
 * @returns {boolean} True si el formato es válido, false en caso contrario.
 */
const isValidEmail = (email) => {
    // Esta expresión regular es estricta: se asegura de que no haya caracteres
    // extraños ni espacios al principio o al final.
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
};

    // Función para inicializar los dropdowns de sexo
    const inicializarDropdown = (dropdownElement) => {
        if (!dropdownElement) return;
        const selectedDisplay = dropdownElement.querySelector('.dropdown-selected');
        const hiddenInput = dropdownElement.querySelector('input[type="hidden"]');
        const optionsContainer = dropdownElement.querySelector('.dropdown-options');
        selectedDisplay.addEventListener('click', (e) => {
            e.stopPropagation();
            document.querySelectorAll('.custom-dropdown.open').forEach(d => {
                if(d !== dropdownElement) d.classList.remove('open');
            });
            dropdownElement.classList.toggle('open');
        });
        optionsContainer.addEventListener('click', (e) => {
            if (e.target.classList.contains('dropdown-option')) {
                selectedDisplay.querySelector('span').textContent = e.target.textContent;
                hiddenInput.value = e.target.dataset.value;
                dropdownElement.classList.remove('open');
            }
        });
    };
    
    inicializarDropdown(document.getElementById('sexo-dropdown'));
    inicializarDropdown(document.getElementById('edit-sexo-dropdown'));
    
    document.addEventListener('click', () => {
        document.querySelectorAll('.custom-dropdown.open').forEach(d => d.classList.remove('open'));
    });

    if (themeToggle) {
        const themeIcon = themeToggle.querySelector('i');
        const applyTheme = (theme) => {
            if (theme === 'dark') {
                body.classList.add('dark-mode');
                if (themeIcon) { themeIcon.classList.remove('fa-moon'); themeIcon.classList.add('fa-sun'); }
                localStorage.setItem('theme', 'dark');
            } else {
                body.classList.remove('dark-mode');
                if (themeIcon) { themeIcon.classList.remove('fa-sun'); themeIcon.classList.add('fa-moon'); }
                localStorage.setItem('theme', 'light');
            }
        };
        const savedTheme = localStorage.getItem('theme') || 'light';
        applyTheme(savedTheme);
        themeToggle.addEventListener('click', () => {
            const currentTheme = body.classList.contains('dark-mode') ? 'light' : 'dark';
            applyTheme(currentTheme);
        });
    }

    if (window.innerWidth > 992) { document.body.classList.add('sidebar-open'); }
    if (openBtn && closeBtn && overlay) {
        openBtn.addEventListener('click', () => { document.body.classList.toggle('sidebar-open'); });
        closeBtn.addEventListener('click', () => { document.body.classList.remove('sidebar-open'); });
        overlay.addEventListener('click', () => { document.body.classList.remove('sidebar-open'); });
    }

    const switchTab = (tabId) => {
        tabContents.forEach(c => c.classList.remove('active'));
        tabLinks.forEach(l => l.classList.remove('active'));
        document.getElementById(tabId).classList.add('active');
        document.querySelector(`.tab-link[data-tab="${tabId}"]`).classList.add('active');
    };
    
    const showInfoModal = (title, message, isSuccess = true, onConfirm = null) => {
        if (!infoModal) return;
        infoModalTitle.textContent = title;
        infoModalMessage.textContent = message;
        infoModalIcon.className = 'modal-icon fas';
        infoModalIcon.classList.add(isSuccess ? 'fa-check-circle' : 'fa-times-circle', isSuccess ? 'success' : 'error');
        infoModal.classList.add('visible');
        const confirmHandler = () => {
            infoModal.classList.remove('visible');
            if (onConfirm) { onConfirm(); }
            infoModalCloseBtn.removeEventListener('click', confirmHandler);
            infoModal.removeEventListener('click', overlayClickHandler);
        };
        const overlayClickHandler = (e) => {
             if (e.target === infoModal) { confirmHandler(); }
        };
        infoModalCloseBtn.addEventListener('click', confirmHandler);
        infoModal.addEventListener('click', overlayClickHandler);
    };

    const authToken = localStorage.getItem('authToken');
    const currentUser = JSON.parse(sessionStorage.getItem('currentUser'));
    if (!authToken || !currentUser) {
        window.location.href = 'home.html';
        return;
    }
    if (sidebarUserName) { sidebarUserName.textContent = currentUser.email; }

    if (logoutBtn && logoutModal) {
        const cancelLogoutBtn = document.getElementById('cancel-logout-btn');
        const confirmLogoutBtn = document.getElementById('confirm-logout-btn');
        logoutBtn.addEventListener('click', (e) => { e.preventDefault(); logoutModal.classList.add('visible'); });
        const closeModal = () => logoutModal.classList.remove('visible');
        cancelLogoutBtn.addEventListener('click', closeModal);
        logoutModal.addEventListener('click', (e) => { if (e.target === logoutModal) closeModal(); });
        confirmLogoutBtn.addEventListener('click', () => {
            sessionStorage.removeItem('currentUser');
            localStorage.removeItem('authToken');
            window.location.href = 'home.html';
        });
    }
    
    const cargarDatosAnexo1 = async () => {
    try {
        const response = await fetch('/api/perfil', { headers: { 'Authorization': `Bearer ${authToken}` } });
        if (!response.ok) { return; }
        const perfil = await response.json();
        if (!perfil) return;
        
        anexoForm1.elements['nombre'].value = perfil.nombre || '';
        anexoForm1.elements['apellidoPaterno'].value = perfil.apellido_paterno || '';
        anexoForm1.elements['apellidoMaterno'].value = perfil.apellido_materno || '';
        anexoForm1.elements['rfc'].value = perfil.rfc || '';
        anexoForm1.elements['curp'].value = perfil.curp || '';
        anexoForm1.elements['telefono'].value = perfil.telefono || '';
        anexoForm1.elements['email'].value = perfil.correo_electronico || '';
        anexoForm1.elements['representanteLegal'].value = perfil.nombre_representante_legal || '';
        anexoForm1.elements['entidad'].value = perfil.entidad_federativa || '';
        anexoForm1.elements['municipio'].value = perfil.municipio || '';
        anexoForm1.elements['localidad'].value = perfil.localidad || '';
        anexoForm1.elements['colonia'].value = perfil.colonia || '';
        anexoForm1.elements['cp'].value = perfil.codigo_postal || '';
        anexoForm1.elements['calle'].value = perfil.calle || '';
        anexoForm1.elements['numExterior'].value = perfil.no_exterior || '';
        anexoForm1.elements['numInterior'].value = perfil.no_interior || '';
        anexoForm1.elements['numIntegrantes'].value = perfil.numero_integrantes || '';
        if (perfil.actividad) {
            const radioBoton = document.querySelector(`input[name="actividad"][value="${perfil.actividad}"]`);
            if (radioBoton) radioBoton.checked = true;
        }
    } catch (error) {
        console.error('Error al cargar datos del Anexo 1:', error);
    }
};

// CÓDIGO PARA REEMPLAZAR EN anexos.js

if (anexoForm1) {
    // --- Selectores de todos los campos a validar ---
    const curpInput = anexoForm1.elements['curp'];
    const rfcInput = anexoForm1.elements['rfc'];
    const emailInput = anexoForm1.elements['email'];
    const numIntegrantesInput = anexoForm1.elements['numIntegrantes'];
    const cpInput = anexoForm1.elements['cp'];
    const telefonoInput = anexoForm1.elements['telefono'];

    // ===================================
    // === VALIDACIÓN EN TIEMPO REAL ===
    // ===================================

    // 1. Validar campos que deben ser SOLO TEXTO (no permite números)
    const textOnlyFields = ['nombre', 'apellidoPaterno', 'apellidoMaterno', 'representanteLegal', 'entidad', 'municipio', 'localidad', 'colonia'];
    
    textOnlyFields.forEach(fieldName => {
        const input = anexoForm1.elements[fieldName];
        if (input) {
            input.addEventListener('input', () => {
                validateTextInput(input);
            });
        }
    });

    // 2. Validar campos con FORMATOS ESPECÍFICOS
    curpInput.addEventListener('input', () => {
        const curp = curpInput.value.toUpperCase();
        if (curp.length === 0 && curpInput.required) {
            showFeedback(curpInput, 'Este campo es obligatorio.', false);
        } else if (isValidCURP(curp)) {
            showFeedback(curpInput, 'CURP válido.', true);
        } else {
            showFeedback(curpInput, 'Formato de CURP incorrecto.', false);
        }
    });

    rfcInput.addEventListener('input', () => {
        const rfc = rfcInput.value.toUpperCase();
        if (rfc.length === 0 && rfcInput.required) {
            showFeedback(rfcInput, 'Este campo es obligatorio.', false);
        } else if (isValidRFC(rfc)) {
            showFeedback(rfcInput, 'RFC válido.', true);
        } else {
            showFeedback(rfcInput, 'Formato de RFC incorrecto.', false);
        }
    });

    emailInput.addEventListener('input', () => {
        const email = emailInput.value;
        if (email.length === 0 && emailInput.required) {
            showFeedback(emailInput, 'Este campo es obligatorio.', false);
        } else if (isValidEmail(email)) {
            showFeedback(emailInput, 'Correo válido.', true);
        } else {
            showFeedback(emailInput, 'Formato de correo incorrecto.', false);
        }
    });

    // 3. Validar campos que deben ser SOLO NÚMEROS (no permite letras ni negativos)
    telefonoInput.addEventListener('input', () => {
        validateNumericInput(telefonoInput, 10);
    });

    numIntegrantesInput.addEventListener('input', () => {
        validateNumericInput(numIntegrantesInput, 3);
    });

    cpInput.addEventListener('input', () => {
        validateNumericInput(cpInput, 5);
    });


    // =====================================
    // === VALIDACIÓN FINAL AL ENVIAR ======
    // =====================================
    anexoForm1.addEventListener('submit', async (e) => {
        e.preventDefault();
        
        let isFormValid = true;
        
        // A. Validar que los campos requeridos no estén vacíos
        anexoForm1.querySelectorAll('input[required]').forEach(input => {
            if (!input.value.trim()) {
                showFeedback(input, 'Este campo es obligatorio.', false);
                isFormValid = false;
            } else {
                if (!input.classList.contains('invalid')) {
                   showFeedback(input, '', true); 
                }
            }
        });

        // B. Re-validar formatos específicos antes de enviar
        if (curpInput.value && !isValidCURP(curpInput.value.toUpperCase())) {
            showFeedback(curpInput, 'Formato de CURP incorrecto.', false);
            isFormValid = false;
        }
        if (rfcInput.value && !isValidRFC(rfcInput.value.toUpperCase())) {
            showFeedback(rfcInput, 'Formato de RFC incorrecto.', false);
            isFormValid = false;
        }
        if (emailInput.value && !isValidEmail(emailInput.value)) {
            showFeedback(emailInput, 'Formato de correo incorrecto.', false);
            isFormValid = false;
        }

        // C. Si el formulario tiene algún error, detenemos el envío
        if (!isFormValid) {
            showInfoModal('Formulario Incompleto', 'Por favor, corrige los campos marcados en rojo.', false);
            return;
        }

        // D. Si todo es válido, preparamos y enviamos los datos
        const anexoData = Object.fromEntries(new FormData(anexoForm1).entries());
        try {
            const response = await fetch('/api/anexo1', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${authToken}` },
                body: JSON.stringify(anexoData)
            });
            const result = await response.json();
            if (!response.ok) throw new Error(result.message);
            showInfoModal('¡Éxito!', result.message, true, () => { window.location.href = 'datos-personales.html'; });
        } catch (error) { 
            showInfoModal('Error al guardar', error.message, false);
        }
    });
}
    
    if (mainCancelButton && cancelModal) {
        const confirmCancelBtn = document.getElementById('confirm-cancel-btn');
        const denyCancelBtn = document.getElementById('deny-cancel-btn');
        mainCancelButton.addEventListener('click', () => cancelModal.classList.add('visible'));
        const closeModal = () => cancelModal.classList.remove('visible');
        denyCancelBtn.addEventListener('click', closeModal);
        cancelModal.addEventListener('click', (e) => { if (e.target === cancelModal) closeModal(); });
        confirmCancelBtn.addEventListener('click', () => { window.location.href = 'datos-personales.html'; });
    }

    const getSexoTexto = (sexoValue) => {
        if (sexoValue === 1 || sexoValue === '1') return 'Masculino';
        if (sexoValue === 0 || sexoValue === '0') return 'Femenino';
        return 'No especificado';
    };

    const cargarIntegrantes = async () => {
        if (!integrantesTableBody) return;
        try {
            const response = await fetch('/api/integrantes', { headers: { 'Authorization': `Bearer ${authToken}` } });
            if (!response.ok) throw new Error('No se pudieron cargar los integrantes.');
            
            integrantesData = await response.json();
            
            integrantesTableBody.innerHTML = '';
            if (integrantesData.length === 0) {
                integrantesTableBody.innerHTML = '<tr><td colspan="6" style="text-align:center; padding: 20px;">Aún no hay integrantes registrados.</td></tr>';
            } else {
                integrantesData.forEach(i => {
                    const row = document.createElement('tr');
                    row.dataset.id = i.id;
                    row.innerHTML = `
                        <td>${i.nombre_completo || ''}</td>
                        <td>${i.rfc || ''}</td>
                        <td>${i.curp || ''}</td>
                        <td>${getSexoTexto(i.sexo)}</td> 
                        <td>${i.telefono || ''}</td>
                        <td>
                            <button class="btn-icon btn-edit"><i class="fas fa-pencil-alt"></i></button>
                            <button class="btn-icon btn-delete"><i class="fas fa-trash-alt"></i></button>
                        </td>`;
                    integrantesTableBody.appendChild(row);
                });
            }
        } catch (error) {
            console.error(error.message);
            integrantesTableBody.innerHTML = '<tr><td colspan="6" style="text-align:center; padding: 20px;">Error al cargar integrantes.</td></tr>';
        }
    };

    if(addIntegranteForm) {
        addIntegranteForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            const integranteData = Object.fromEntries(new FormData(addIntegranteForm).entries());
            try {
                const response = await fetch('/api/integrantes', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${authToken}` },
                    body: JSON.stringify(integranteData)
                });
                const result = await response.json();
                if (!response.ok) throw new Error(result.message);
                
                showInfoModal('¡Éxito!', result.message, true);
                addIntegranteForm.reset();
                document.querySelector('#sexo-dropdown .dropdown-selected span').textContent = 'Seleccione una opción';
                cargarIntegrantes();
            } catch (error) { 
                showInfoModal('Error', error.message, false);
            }
        });
    }

    if(integrantesTableBody) {
        integrantesTableBody.addEventListener('click', (e) => {
            const target = e.target.closest('button');
            if (!target) return;
            const row = target.closest('tr');
            const id = row.dataset.id;
            if (target.classList.contains('btn-edit')) {
                const integrante = integrantesData.find(i => i.id == id);
                if (integrante) {
                    integranteEditId = id;
                    editForm.elements['nombre_completo'].value = integrante.nombre_completo || '';
                    editForm.elements['rfc'].value = integrante.rfc || '';
                    editForm.elements['curp'].value = integrante.curp || '';
                    editForm.elements['telefono'].value = integrante.telefono || '';
                    editForm.elements['ultimo_grado_estudio'].value = integrante.ultimo_grado_estudio || '';
                    editForm.elements['actividad_desempena'].value = integrante['actividad_desempeña'] || '';
                    editForm.elements['localidad'].value = integrante.localidad || '';
                    editForm.elements['municipio'].value = integrante.municipio || '';
                    
                    const sexoTexto = getSexoTexto(integrante.sexo);
                    const editSexoDropdown = document.getElementById('edit-sexo-dropdown');
                    editSexoDropdown.querySelector('.dropdown-selected span').textContent = sexoTexto;
                    editSexoDropdown.querySelector('#edit-int-sexo-hidden').value = integrante.sexo;

                    editModal.classList.add('visible');
                }
            }
            if (target.classList.contains('btn-delete')) {
                deleteModal.classList.add('visible');
                const confirmDeleteBtn = document.getElementById('confirm-delete-btn');
                const denyDeleteBtn = document.getElementById('deny-delete-btn');
                
                const handleConfirmDelete = async () => {
                    try {
                        const response = await fetch(`/api/integrantes/${id}`, {
                            method: 'DELETE',
                            headers: { 'Authorization': `Bearer ${authToken}` }
                        });
                        const result = await response.json();
                        if (!response.ok) throw new Error(result.message);
                        
                        showInfoModal('¡Éxito!', result.message, true);
                        cargarIntegrantes();
                    } catch (error) {
                        showInfoModal('Error', error.message, false);
                    }
                    closeDeleteModal();
                };

                const closeDeleteModal = () => {
                    deleteModal.classList.remove('visible');
                    confirmDeleteBtn.removeEventListener('click', handleConfirmDelete);
                };

                confirmDeleteBtn.addEventListener('click', handleConfirmDelete, { once: true });
                denyDeleteBtn.addEventListener('click', closeDeleteModal, { once: true });
                deleteModal.addEventListener('click', (e) => {
                    if(e.target === deleteModal) closeDeleteModal();
                }, { once: true });
            }
        });
    }

    const closeEditModal = () => {
        editModal.classList.remove('visible');
        editForm.reset();
        integranteEditId = null;
    };
    if(cancelEditModalBtn) cancelEditModalBtn.addEventListener('click', closeEditModal);
    if(editModal) editModal.addEventListener('click', e => { if(e.target === editModal) closeEditModal(); });
    if(editForm) editForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        if(!integranteEditId) return;
        
        const integranteData = Object.fromEntries(new FormData(editForm).entries());
        try {
            const response = await fetch(`/api/integrantes/${integranteEditId}`, {
                method: 'PUT',
                headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${authToken}` },
                body: JSON.stringify(integranteData)
            });
            const result = await response.json();
            if (!response.ok) throw new Error(result.message);
            
            showInfoModal('¡Éxito!', 'Integrante actualizado correctamente.', true);
            closeEditModal();
            cargarIntegrantes();
        } catch (error) {
            showInfoModal('Error', error.message, false);
        }
    });

    const cargarDatosAnexo3 = async () => {
        if (!anexoForm3) return;
        try {
            const response = await fetch('/api/anexos/anexo3', { headers: { 'Authorization': `Bearer ${authToken}` } });
            if (!response.ok) throw new Error('No se pudieron cargar los datos.');
            const data = await response.json();
            
            anexoForm3.reset();
            anexoForm3.querySelectorAll('input[type=checkbox]').forEach(chk => chk.checked = false);
            anexoForm3.querySelectorAll('input[name*="_opcion"][value="no"]').forEach(radio => radio.checked = true);

            const tecnicos = data.datos_tecnicos || {};
            if (Object.keys(tecnicos).length > 0) {
                anexoForm3.elements['lugar_captura'].value = tecnicos.lugar || '';
                anexoForm3.elements['localidad_captura'].value = tecnicos.localidad_captura || '';
                anexoForm3.elements['municipio_captura'].value = tecnicos.municipio_captura || '';
                anexoForm3.elements['sitio_desembarque'].value = tecnicos.sitio_desembarque || '';
                anexoForm3.elements['localidad_desembarque'].value = tecnicos.localidad_desembarque || '';
                anexoForm3.elements['municipio_desembarque'].value = tecnicos.municipio_desembarque || '';
                if (tecnicos.tipo_pesqueria) {
                    const radioTipo = anexoForm3.querySelector(`input[name="tipo_pesqueria"][value="${tecnicos.tipo_pesqueria}"]`);
                    if (radioTipo) radioTipo.checked = true;
                }
                const fillCheckboxes = (fieldName, dbValue) => {
                    if (!dbValue) return;
                    dbValue.split(',').forEach(val => {
                        const checkbox = anexoForm3.querySelector(`input[name="${fieldName}[]"][value="${val}"]`);
                        if (checkbox) checkbox.checked = true;
                    });
                };
                fillCheckboxes('pesqueria', tecnicos.pesqueria);
                fillCheckboxes('especies_objetivo', tecnicos.especies_objetivo);
                fillCheckboxes('certificados', tecnicos.certificados_solicitantes);
                if (tecnicos.arte_pesca) {
                    tecnicos.arte_pesca.split(',').forEach(item => {
                        if (!item) return;
                        const [nombre, cantidad] = item.split(':');
                        const chk = anexoForm3.querySelector(`input[name="artes_pesca[]"][value="${nombre}"]`);
                        if (chk) {
                            chk.checked = true;
                            const cantInputName = `cantidad_${nombre.toLowerCase().replace(/ /g, '_')}`;
                            if (anexoForm3.elements[cantInputName]) anexoForm3.elements[cantInputName].value = cantidad;
                        }
                    });
                }
                if (tecnicos.nivel_produccion_anual) {
                    const parts = tecnicos.nivel_produccion_anual.split(' ');
                    const cantidad = parts[0];
                    const unidad = parts.slice(1).join(' ');
                    anexoForm3.elements['nivel_produccion_anual'].value = cantidad;
                    if (unidad) {
                        const radioUnidad = anexoForm3.querySelector(`input[name="produccion_unidad"][value="${unidad}"]`);
                        if (radioUnidad) radioUnidad.checked = true;
                    }
                }
            }

            const unidad = data.unidad_pesquera || {};
            if (Object.keys(unidad).length > 0) {
                const setActivoFields = (dbColPrefix, formNamePrefix, items) => {
                    items.forEach(item => {
                        const optionCol = `${dbColPrefix}_${item}`;
                        const qtyCol = `${optionCol}_cantidad`;
                        const optionInputName = `${formNamePrefix}_${item}_opcion`;
                        const qtyInputName = `${formNamePrefix}_${item}_cantidad`;

                        if (unidad.hasOwnProperty(optionCol)) {
                            const radioValue = unidad[optionCol] ? 'si' : 'no';
                            const radio = anexoForm3.querySelector(`input[name="${optionInputName}"][value="${radioValue}"]`);
                            if (radio) radio.checked = true;
                        }
                        if (unidad.hasOwnProperty(qtyCol)) {
                            const cantInput = anexoForm3.querySelector(`input[name="${qtyInputName}"]`);
                            if (cantInput) cantInput.value = unidad[qtyCol] || 0;
                        }
                    });
                };

                if (unidad.hasOwnProperty('motores')) {
                    const radioValue = unidad.motores ? 'si' : 'no';
                    const radio = anexoForm3.querySelector(`input[name="motores_opcion"][value="${radioValue}"]`);
                    if (radio) radio.checked = true;
                    const cantInput = anexoForm3.querySelector(`input[name="motores_cantidad"]`);
                    if (cantInput) cantInput.value = unidad.motores_cantidad || 0;
                }
                
                setActivoFields('emb', 'embarcacion', ['madera', 'fibra', 'metal']);
                setActivoFields('cons', 'conservacion', ['hielera', 'refrigerador', 'cuartofrio']);
                setActivoFields('trans', 'transporte', ['camioneta', 'cajafria', 'camion']);
            }
        } catch (error) {
            console.error("Error al cargar datos del Anexo 3:", error);
            showInfoModal('Error de Carga', 'No se pudieron obtener los datos del Anexo 3.', false);
        }
    };

    if (anexoForm3) {
        anexoForm3.addEventListener('submit', async (e) => {
            e.preventDefault();
            const formData = new FormData(anexoForm3);

            const dataToSend = {
                datos_tecnicos: {
                    lugar_captura: formData.get('lugar_captura'),
                    localidad_captura: formData.get('localidad_captura'),
                    municipio_captura: formData.get('municipio_captura'),
                    sitio_desembarque: formData.get('sitio_desembarque'),
                    localidad_desembarque: formData.get('localidad_desembarque'),
                    municipio_desembarque: formData.get('municipio_desembarque'),
                    tipo_pesqueria: formData.get('tipo_pesqueria'),
                    nivel_produccion_anual: formData.get('nivel_produccion_anual'),
                    produccion_unidad: formData.get('produccion_unidad'),
                    pesqueria: formData.getAll('pesqueria[]'),
                    arte_pesca_string: formData.getAll('artes_pesca[]').map(arte => `${arte}:${formData.get(`cantidad_${arte.toLowerCase().replace(/ /g, '_')}`) || 0}`).join(','),
                    especies_objetivo_string: formData.getAll('especies_objetivo[]').join(','),
                    certificados_string: formData.getAll('certificados[]').join(',')
                },
                unidad_pesquera: {
                    embarcaciones: {
                        madera: { opcion: formData.get('embarcacion_madera_opcion'), cantidad: formData.get('embarcacion_madera_cantidad') || 0 },
                        fibra: { opcion: formData.get('embarcacion_fibra_opcion'), cantidad: formData.get('embarcacion_fibra_cantidad') || 0 },
                        metal: { opcion: formData.get('embarcacion_metal_opcion'), cantidad: formData.get('embarcacion_metal_cantidad') || 0 }
                    },
                    motores: {
                        opcion: formData.get('motores_opcion'),
                        cantidad: formData.get('motores_cantidad') || 0
                    },
                    sistema_conservacion: {
                        hielera: { opcion: formData.get('conservacion_hielera_opcion'), cantidad: formData.get('conservacion_hielera_cantidad') || 0 },
                        refrigerador: { opcion: formData.get('conservacion_refrigerador_opcion'), cantidad: formData.get('conservacion_refrigerador_cantidad') || 0 },
                        cuarto: { opcion: formData.get('conservacion_cuarto_opcion'), cantidad: formData.get('conservacion_cuarto_cantidad') || 0 }
                    },
                    equipo_transporte: {
                        camioneta: { opcion: formData.get('transporte_camioneta_opcion'), cantidad: formData.get('transporte_camioneta_cantidad') || 0 },
                        caja: { opcion: formData.get('transporte_caja_opcion'), cantidad: formData.get('transporte_caja_cantidad') || 0 },
                        camion: { opcion: formData.get('transporte_camion_opcion'), cantidad: formData.get('transporte_camion_cantidad') || 0 }
                    }
                }
            };
            
            try {
                const response = await fetch('/api/anexos/anexo3', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${authToken}` },
                    body: JSON.stringify(dataToSend)
                });
                const result = await response.json();
                if (!response.ok) throw new Error(result.message);
                
                showInfoModal('¡Éxito!', result.message, true);
                cargarDatosAnexo3(); 
            } catch (error) {
                showInfoModal('Error al Guardar', error.message, false);
            }
        });
    }

    // --- LÓGICA ANEXO 4 (BLOQUE COMPLETO Y CORREGIDO) ---
    // En public/anexos.js

const cargarDatosAnexo4 = async () => {
    if (!anexoForm4) return;

    // --- FUNCIONES AUXILIARES ---

    const setInputValue = (name, value) => {
        if (anexoForm4.elements[name]) {
            anexoForm4.elements[name].value = value || '';
        }
    };
    
    // Función original para botones de radio con valor "si" / "no"
    const setRadioValue = (name, value) => {
        const valueToSelect = value ? 'si' : 'no';
        const radio = anexoForm4.querySelector(`input[name="${name}"][value="${valueToSelect}"]`);
        if (radio) radio.checked = true;
    };

    // Nueva función para botones de radio que guardan texto (ej: "comercial", "granja")
    const setRadioValueWithString = (name, dbValue) => {
        if (!dbValue) return; // Si no hay valor guardado, no se hace nada
        // Busca el radio button cuyo 'value' coincide exactamente con el texto de la base de datos
        const radio = anexoForm4.querySelector(`input[name="${name}"][value="${dbValue}"]`);
        if (radio) {
            radio.checked = true;
        }
    };

    // --- LÓGICA PRINCIPAL ---

    try {
        const response = await fetch('/api/anexos/acuacultura', { headers: { 'Authorization': `Bearer ${authToken}` } });
        if (!response.ok) throw new Error('No se pudieron obtener los datos del Anexo 4.');
        
        const data = await response.json();

        if (!data) {
            console.log("No se encontraron datos existentes para el Anexo 4.");
            return;
        }

        // --- PARTE 1: DATOS GENERALES ---
        setRadioValue('instalacionPropia', data.instalacion_propia === 'si');
        setInputValue('contratoArrendamientoAnos', data.contrato_arrendamiento_anios);
        setInputValue('dimensionesUnidad', data.dimensiones_unidad_produccion);
        
        // Se usa la nueva función para los campos con texto
        setRadioValueWithString('tipo', data.tipo);
        setRadioValueWithString('tipoInstalacion', data.tipo_instalacion);
        setRadioValueWithString('sistemaProduccion', data.sistema_produccion);
        
        setInputValue('produccionAnualValor', data.produccion_anual_valor);
        setInputValue('produccionAnualUnidad', data.produccion_anual_unidad);

        if (data.especies && typeof data.especies === 'object') {
            (data.especies.seleccionadas || []).forEach(val => {
                const chk = anexoForm4.querySelector(`input[name="especies"][value="${val}"]`);
                if (chk) chk.checked = true;
            });
            setInputValue('especiesOtras', data.especies.otras);
        }

        if (data.certificados && typeof data.certificados === 'object') {
            (data.certificados.seleccionados || []).forEach(val => {
                const chk = anexoForm4.querySelector(`input[name="certificados"][value="${val}"]`);
                if (chk) chk.checked = true;
            });
            setInputValue('certificadoSanidadCual', data.certificados.sanidad);
            setInputValue('certificadoInocuidadCual', data.certificados.inocuidad);
            setInputValue('certificadoBuenasPracticasCual', data.certificados.buenas_practicas);
            setInputValue('certificadoOtrosCual', data.certificados.otros);
        }

        // --- PARTE 2: SECCIÓN 10 (ACTIVOS) ---
        // 10.1 Tipo de estanques
        setRadioValue('estanque_rustico_opcion', data.rustico);
        setInputValue('estanque_rustico_cantidad', data.rustico_cantidad);
        setInputValue('estanque_rustico_dimensiones', data.rustico_dimensiones);
        setRadioValue('estanque_geomembrana_opcion', data.geomembrana);
        setInputValue('estanque_geomembrana_cantidad', data.geomembrana_cantidad);
        setInputValue('estanque_geomembrana_dimensiones', data.geomembrana_dimensiones);
        setRadioValue('estanque_concreto_opcion', data.concreto);
        setInputValue('estanque_concreto_cantidad', data.concreto_cantidad);
        setInputValue('estanque_concreto_dimensiones', data.concreto_dimensiones);

        // 10.2 Instrumentos de medición
        setRadioValue('instrumento_temperatura_opcion', data.instrumento_temperatura);
        setInputValue('instrumento_temperatura_cantidad', data.instrumento_temperatura_cantidad);
        setRadioValue('instrumento_oxigeno_opcion', data.instrumento_oxigeno);
        setInputValue('instrumento_oxigeno_cantidad', data.instrumento_oxigeno_cantidad);
        setRadioValue('instrumento_ph_opcion', data.instrumento_ph);
        setInputValue('instrumento_ph_cantidad', data.instrumento_ph_cantidad);
        
        // 10.3 Sistema de conservación
        setRadioValue('conservacion_hielera_opcion', data.conservacion_hielera);
        setInputValue('conservacion_hielera_cantidad', data.conservacion_hielera_cantidad);
        setRadioValue('conservacion_refrigerador_opcion', data.conservacion_refrigerado);
        setInputValue('conservacion_refrigerador_cantidad', data.conservacion_refrigerado_cantidad);
        setRadioValue('conservacion_cuartofrio_opcion', data.conservacion_cuartofrio);
        setInputValue('conservacion_cuartofrio_cantidad', data.conservacion_cuartofrio_cantidad);

        // 10.4 Equipo de transporte
        setRadioValue('transporte_lancha_opcion', data.transporte_lancha);
        setInputValue('transporte_lancha_cantidad', data.transporte_lancha_cantidad);
        setRadioValue('transporte_camioneta_opcion', data.transporte_camioneta);
        setInputValue('transporte_camioneta_cantidad', data.transporte_camioneta_cantidad);
        setRadioValue('transporte_cajafria_opcion', data.transporte_cajafria);
        setInputValue('transporte_cajafria_cantidad', data.transporte_cajafria_cantidad);
        
        // 10.5 Embarcaciones
        setRadioValue('embarcacion_madera_opcion', data.embarcacion_madera);
        setInputValue('embarcacion_madera_cantidad', data.embarcacion_madera_cantidad);
        setRadioValue('embarcacion_fibra_vidrio_opcion', data.embarcacion_fibra_vidrio);
        setInputValue('embarcacion_fibra_vidrio_cantidad', data.embarcacion_fibra_vidrio_cantidad);
        setRadioValue('embarcacion_metal_opcion', data.embarcacion_metal);
        setInputValue('embarcacion_metal_cantidad', data.embarcacion_metal_cantidad);
        
        // 10.6 Instalación hidráulica y aireación
        setRadioValue('hidraulica_bomba_opcion', data.hidraulica_bomba_agua);
        setInputValue('hidraulica_bomba_cantidad', data.hidraulica_bomba_agua_cantidad);
        setRadioValue('hidraulica_aireador_opcion', data.hidraulica_aireador);
        setInputValue('hidraulica_aireador_cantidad', data.hidraulica_aireador_cantidad);

    } catch (error) {
        console.error("Error al cargar datos del Anexo 4:", error);
        showInfoModal('Error de Carga', 'No se pudieron obtener los datos del Anexo 4.', false);
    }
};
    
   if (anexoForm4) {
    anexoForm4.addEventListener('submit', async (e) => {
        e.preventDefault();
        const formData = new FormData(anexoForm4);

        // =================================================================
        // CAMBIO PRINCIPAL: Se elimina "formatSection" y se envían
        // los datos del formulario directamente.
        // =================================================================
        const dataToSend = Object.fromEntries(formData.entries());

        // Esto es para asegurar que los arrays de checkboxes se envíen correctamente
        dataToSend.especies = formData.getAll('especies');
        dataToSend.certificados = formData.getAll('certificados');
        // =================================================================

        try {
            const response = await fetch('/api/anexos/acuacultura', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${authToken}` },
                body: JSON.stringify(dataToSend)
            });
            const result = await response.json();
            if (!response.ok) throw new Error(result.message);
            showInfoModal('¡Éxito!', result.message, true);
        } catch (error) {
            showInfoModal('Error al Guardar', error.message, false);
        }
    });
}

initAnexo5(authToken, showInfoModal);

    // --- LÓGICA DE NAVEGACIÓN POR PESTAÑAS Y CARGA INICIAL ---
    tabLinks.forEach(link => {
        link.addEventListener('click', () => {
            const tabId = link.dataset.tab;
            window.location.hash = tabId;
            
            switchTab(tabId);
            
            if (tabId === 'anexo1') { cargarDatosAnexo1(); }
            if (tabId === 'anexo2') { cargarIntegrantes(); }
            if (tabId === 'anexo3') { cargarDatosAnexo3(); }
            if (tabId === 'anexo4') { cargarDatosAnexo4(); }
            if (tabId === 'anexo5') { cargarEmbarcaciones(); }
        });
    });

    const checkUrlHash = () => {
        const hash = window.location.hash.substring(1);
        const validTabIds = ['anexo1', 'anexo2', 'anexo3', 'anexo4', 'anexo5'];
        
        if (hash && validTabIds.includes(hash)) {
            switchTab(hash);
            if (hash === 'anexo1') cargarDatosAnexo1();
            if (hash === 'anexo2') cargarIntegrantes();
            if (hash === 'anexo3') cargarDatosAnexo3();
            if (hash === 'anexo4') cargarDatosAnexo4();
            if (hash === 'anexo5') cargarEmbarcaciones();
        } else {
            switchTab('anexo1')
            cargarDatosAnexo1();
        }
    };
    
    checkUrlHash(); 
});