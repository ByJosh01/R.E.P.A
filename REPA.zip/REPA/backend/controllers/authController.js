// backend/controllers/authController.js
const userModel = require('../models/userModel');
const sgMail = require('@sendgrid/mail');
const crypto = require('crypto');
const axios = require('axios');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');

sgMail.setApiKey('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'); // Tu API Key
const SENDER_EMAIL = 'sunix2920@gmail.com'; // Tu correo
const JWT_SECRET = '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';

const generateToken = (userId) => {
    return jwt.sign({ id: userId }, JWT_SECRET, { expiresIn: '1d' });
};

exports.registerUser = async (req, res) => {
    try {
        const { curp, email, password, recaptchaToken } = req.body;

        if (!recaptchaToken) {
            return res.status(400).json({ message: 'La verificación reCAPTCHA es requerida.' });
        }
        const secretKey = '6LdkpMIrAAAAAPO-Uf6SWDt5e2VIGJybLN1xIpyE'; // Tu clave secreta
        const verificationURL = `https://www.google.com/recaptcha/api/siteverify?secret=${secretKey}&response=${recaptchaToken}`;
        const verificationResponse = await axios.post(verificationURL);
        if (!verificationResponse.data.success) {
            return res.status(400).json({ message: 'Falló la verificación reCAPTCHA.' });
        }

        if (await userModel.findUserByCurp(curp) || await userModel.findUserByEmail(email)) {
            return res.status(400).json({ message: 'El CURP o correo electrónico ya existe.' });
        }
        
        await userModel.createUser({ curp, email, password });
        
        const msg = {
            to: email, from: SENDER_EMAIL, subject: '¡Bienvenido! Tu cuenta ha sido creada ✔',
            html: `<h1>¡Felicidades!</h1><p>Tu cuenta se creó correctamente.</p>`
        };
        sgMail.send(msg).catch(error => console.error("Error al enviar correo:", error));
        
        res.status(201).json({ message: 'Usuario registrado exitosamente.' });
    } catch (error) {
        res.status(500).json({ message: "Error en el servidor al registrar." });
    }
};

exports.loginUser = async (req, res) => {
    try {
        const { curp, password } = req.body;
        const user = await userModel.findUserByCurp(curp);

        if (user && await bcrypt.compare(password, user.password)) {
            const token = generateToken(user.id);
            res.status(200).json({ 
                message: 'Inicio de sesión exitoso.', 
                token, 
                user: { curp: user.curp, email: user.email } 
            });
        } else {
            res.status(401).json({ message: 'CURP o contraseña incorrectos.' });
        }
    } catch (error) {
        res.status(500).json({ message: "Error en el servidor al iniciar sesión." });
    }
};

exports.forgotPassword = async (req, res) => {
    try {
        const { email } = req.body;
        const user = await userModel.findUserByEmail(email);
        if (user) {
            const token = crypto.randomBytes(32).toString('hex');
            const expires = Date.now() + 15 * 60 * 1000;
            await userModel.saveResetToken(email, token, expires);
            const resetLink = `http://localhost:3000/reset-password.html?token=${token}`;
            const msg = {
                to: email, from: SENDER_EMAIL, subject: 'Recuperación de Contraseña',
                html: `<p>Haz clic en el siguiente enlace para restablecer tu contraseña:</p><a href="${resetLink}">Restablecer Contraseña</a><p>El enlace expira en 15 minutos.</p>`
            };
            sgMail.send(msg).catch(error => console.error("Error al enviar correo:", error));
        }
        res.status(200).json({ message: 'Si tu correo está registrado, recibirás un enlace.' });
    } catch (error) {
        res.status(500).json({ message: "Error en el servidor." });
    }
};

exports.resetPassword = async (req, res) => {
    try {
        const { token, newPassword } = req.body;
        const tokenData = await userModel.findTokenData(token);
        if (!tokenData || new Date(tokenData.expires).getTime() < Date.now()) {
            return res.status(400).json({ message: 'Token inválido o expirado.' });
        }
        await userModel.updateUserPassword(tokenData.email, newPassword);
        await userModel.deleteResetToken(token);
        res.status(200).json({ message: 'Contraseña actualizada con éxito.' });
    } catch (error) {
        res.status(500).json({ message: "Error en el servidor." });
    }
};