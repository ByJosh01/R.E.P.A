// backend/middleware/authMiddleware.js
const jwt = require('jsonwebtoken');
const pool = require('../db');
const JWT_SECRET = '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';

exports.protect = async (req, res, next) => {
    let token;

    if (req.headers.authorization && req.headers.authorization.startsWith('Bearer')) {
        try {
            token = req.headers.authorization.split(' ')[1];
            const decoded = jwt.verify(token, JWT_SECRET);

            // Buscamos al usuario Y su perfil de solicitante al mismo tiempo
            const [rows] = await pool.query(
                `SELECT u.id, u.curp, u.email, s.solicitante_id 
                 FROM usuarios u 
                 LEFT JOIN solicitantes s ON u.id = s.usuario_id 
                 WHERE u.id = ?`,
                [decoded.id]
            );
            
            if (!rows[0]) {
                 return res.status(401).json({ message: 'No autorizado, usuario no encontrado.' });
            }

            // Adjuntamos toda la info útil a la petición (incluyendo el solicitante_id)
            req.user = rows[0];

            next();
        } catch (error) {
            console.error("Error en middleware:", error);
            res.status(401).json({ message: 'No autorizado, el token falló o ha expirado.' });
        }
    }

    if (!token) {
        res.status(401).json({ message: 'No autorizado, no se encontró token en la petición.' });
    }
};