-- MySQL dump 10.13  Distrib 8.0.42, for Win64 (x86_64)
--
-- Host: localhost    Database: repa
-- ------------------------------------------------------
-- Server version	8.0.42

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `datos_tecnicos_acuacultura`
--

DROP TABLE IF EXISTS `datos_tecnicos_acuacultura`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `datos_tecnicos_acuacultura` (
  `id` int NOT NULL AUTO_INCREMENT,
  `solicitante_id` int NOT NULL,
  `instalacion_propia` enum('si','no') DEFAULT NULL,
  `contrato_arrendamiento_anios` int unsigned DEFAULT NULL COMMENT 'Años de arrendamiento. Solo si la instalación no es propia.',
  `dimensiones_unidad_produccion` text,
  `tipo` enum('comercial','didactica','investigacion','fomento') DEFAULT NULL,
  `especies` json DEFAULT NULL COMMENT 'Almacena un objeto con las especies seleccionadas y el campo "otras". Ej: {"seleccionadas": ["mojarra"], "otras": "Carpa"}',
  `tipo_instalacion` enum('granja','centro_acuicola','laboratorio') DEFAULT NULL,
  `sistema_produccion` enum('intensivo','semi_intensivo','extensivo','hiperintensivo') DEFAULT NULL,
  `produccion_anual_valor` decimal(10,2) DEFAULT NULL COMMENT 'El valor numérico de la producción.',
  `produccion_anual_unidad` enum('kilogramos','toneladas','miles_toneladas') DEFAULT NULL COMMENT 'La unidad de medida para la producción.',
  `certificados` json DEFAULT NULL COMMENT 'Almacena un objeto con los certificados seleccionados y sus descripciones. Ej: {"sanidad": "Certificado XYZ", "ninguno": true}',
  `unidad_produccion_id` int DEFAULT NULL,
  `fecha_creacion` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `fecha_actualizacion` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `solicitante_id_UNIQUE` (`solicitante_id`),
  KEY `fk_datos_acuacultura_solicitante_idx` (`solicitante_id`),
  KEY `fk_acuacultura_unidad_produccion` (`unidad_produccion_id`),
  CONSTRAINT `fk_acuacultura_unidad_produccion` FOREIGN KEY (`unidad_produccion_id`) REFERENCES `unidad_produccion` (`id`),
  CONSTRAINT `fk_datos_acuacultura_solicitante` FOREIGN KEY (`solicitante_id`) REFERENCES `solicitantes` (`solicitante_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=103 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='Almacena los datos técnicos de acuacultura correspondientes al Anexo 4.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `datos_tecnicos_acuacultura`
--

LOCK TABLES `datos_tecnicos_acuacultura` WRITE;
/*!40000 ALTER TABLE `datos_tecnicos_acuacultura` DISABLE KEYS */;
INSERT INTO `datos_tecnicos_acuacultura` VALUES (1,2,'si',3,'300x350',NULL,'{\"otras\": \"HOLAA\", \"seleccionadas\": [\"langostino\", \"mojarra\", \"bagre\"]}','granja',NULL,60.00,NULL,'{\"otros\": \"\", \"sanidad\": \"\", \"inocuidad\": \"\", \"seleccionados\": [\"sanidad\", \"inocuidad\", \"buenas_practicas\"], \"buenas_practicas\": \"\"}',NULL,'2025-09-21 01:00:30','2025-09-23 10:41:34'),(93,5,'si',9,'200x200','didactica','{\"otras\": \"\", \"seleccionadas\": [\"langostino\", \"mojarra\", \"caracol\", \"tilapia\", \"bagre\"]}','centro_acuicola','extensivo',788.00,'toneladas','{\"otros\": \"\", \"sanidad\": \"\", \"inocuidad\": \"\", \"seleccionados\": [\"inocuidad\", \"buenas_practicas\"], \"buenas_practicas\": \"\"}',NULL,'2025-09-24 02:24:16','2025-09-24 02:24:16'),(95,6,'si',5,NULL,NULL,'{\"otras\": \"\", \"seleccionadas\": [\"langostino\", \"mojarra\", \"caracol\", \"tilapia\"]}',NULL,NULL,NULL,NULL,'{\"otros\": \"\", \"sanidad\": \"\", \"inocuidad\": \"\", \"seleccionados\": [], \"buenas_practicas\": \"\"}',NULL,'2025-09-25 16:16:09','2025-09-25 16:26:53'),(101,7,NULL,NULL,NULL,NULL,'{\"otras\": \"\", \"seleccionadas\": []}',NULL,NULL,NULL,NULL,'{\"otros\": \"\", \"sanidad\": \"\", \"inocuidad\": \"\", \"seleccionados\": [], \"buenas_practicas\": \"\"}',NULL,'2025-09-25 17:38:52','2025-09-25 17:38:52');
/*!40000 ALTER TABLE `datos_tecnicos_acuacultura` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `datos_tecnicos_pesca`
--

DROP TABLE IF EXISTS `datos_tecnicos_pesca`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `datos_tecnicos_pesca` (
  `id` int NOT NULL AUTO_INCREMENT,
  `lugar` varchar(100) DEFAULT NULL,
  `localidad_captura` varchar(100) DEFAULT NULL,
  `municipio_captura` varchar(100) DEFAULT NULL,
  `localidad_desembarque` varchar(100) DEFAULT NULL,
  `municipio_desembarque` varchar(100) DEFAULT NULL,
  `pesqueria` varchar(100) DEFAULT NULL,
  `tipo_pesqueria` varchar(100) DEFAULT NULL,
  `arte_pesca` varchar(100) DEFAULT NULL,
  `especies_objetivo` varchar(100) DEFAULT NULL,
  `certificados_solicitantes` varchar(100) DEFAULT NULL,
  `nivel_produccion_anual` varchar(200) DEFAULT NULL,
  `fecha_actualizacion` datetime DEFAULT CURRENT_TIMESTAMP,
  `solicitante_id` int DEFAULT NULL,
  `sitio_desembarque` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `solicitante_id` (`solicitante_id`),
  CONSTRAINT `datos_tecnicos_pesca_ibfk_1` FOREIGN KEY (`solicitante_id`) REFERENCES `solicitantes` (`solicitante_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `datos_tecnicos_pesca`
--

LOCK TABLES `datos_tecnicos_pesca` WRITE;
/*!40000 ALTER TABLE `datos_tecnicos_pesca` DISABLE KEYS */;
INSERT INTO `datos_tecnicos_pesca` VALUES (3,'Mexico','Veracruz','','','','','Comercial','','Almeja,Cangrejo,Caracol,Jaiba','','','2025-09-15 00:08:53',2,'hola'),(4,'Mexico','Veracruz','veracruz','','','Escama,Crustáceos','Deportiva/Recreativa','Red agallera:0,Trampa nasa:0,Trampa de aro:0','Escama,Caracol','Sanidad','900 Kilogramos','2025-09-23 20:21:56',5,'hola'),(5,'Mexico','Veracruz','Mexico','Veracruz','Mexico','Escama,Crustáceos','Deportiva/Recreativa','Red agallera:90,Atarraya:10','','','','2025-09-25 10:14:15',6,'Poza Rica');
/*!40000 ALTER TABLE `datos_tecnicos_pesca` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `embarcaciones`
--

DROP TABLE IF EXISTS `embarcaciones`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `embarcaciones` (
  `id` int NOT NULL AUTO_INCREMENT,
  `embarcacion_madera` tinyint(1) DEFAULT NULL,
  `embarcacion_madera_cantidad` int DEFAULT NULL,
  `embarcacion_fibra_vidrio` tinyint(1) DEFAULT NULL,
  `embarcacion_fibra_vidrio_cantidad` int DEFAULT NULL,
  `embarcacion_metal` tinyint(1) DEFAULT NULL,
  `embarcacion_metal_cantidad` int DEFAULT NULL,
  `solicitante_id` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `solicitante_id_UNIQUE` (`solicitante_id`)
) ENGINE=InnoDB AUTO_INCREMENT=40 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `embarcaciones`
--

LOCK TABLES `embarcaciones` WRITE;
/*!40000 ALTER TABLE `embarcaciones` DISABLE KEYS */;
INSERT INTO `embarcaciones` VALUES (1,0,NULL,1,80,0,NULL,2),(32,0,NULL,0,NULL,0,NULL,5),(34,0,NULL,0,NULL,0,NULL,6),(38,0,NULL,0,NULL,0,NULL,7);
/*!40000 ALTER TABLE `embarcaciones` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `embarcaciones_menores`
--

DROP TABLE IF EXISTS `embarcaciones_menores`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `embarcaciones_menores` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nombre_embarcacion` varchar(100) DEFAULT NULL,
  `matricula` varchar(50) DEFAULT NULL,
  `tonelaje_neto` varchar(100) DEFAULT NULL,
  `marca` varchar(100) DEFAULT NULL,
  `numero_serie` varchar(100) DEFAULT NULL,
  `potencia_hp` varchar(50) DEFAULT NULL,
  `puerto_base` varchar(100) DEFAULT NULL,
  `solicitante_id` int DEFAULT NULL,
  `fecha_actualizacion` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `solicitante_id` (`solicitante_id`),
  CONSTRAINT `embarcaciones_menores_ibfk_1` FOREIGN KEY (`solicitante_id`) REFERENCES `solicitantes` (`solicitante_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `embarcaciones_menores`
--

LOCK TABLES `embarcaciones_menores` WRITE;
/*!40000 ALTER TABLE `embarcaciones_menores` DISABLE KEYS */;
INSERT INTO `embarcaciones_menores` VALUES (1,'Joshua Emmanuel Estrada','22ISIC996','1','ejemplo','2999003888444','100','2',6,'2025-09-25 10:18:27'),(2,'Janet Nochebuena Hernandez','212T0208','300','ejemplo','098880977','60','667',6,'2025-09-25 10:20:49'),(4,'Joshua Emmanuel Estrada','CARI8008109Q9','90','ejemplo','9230239023','60','2',2,'2025-09-25 12:19:27');
/*!40000 ALTER TABLE `embarcaciones_menores` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `equipo_transporte`
--

DROP TABLE IF EXISTS `equipo_transporte`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `equipo_transporte` (
  `id` int NOT NULL AUTO_INCREMENT,
  `transporte_lancha` tinyint(1) DEFAULT NULL,
  `transporte_lancha_cantidad` int DEFAULT NULL,
  `transporte_camioneta` tinyint(1) DEFAULT NULL,
  `transporte_camioneta_cantidad` int DEFAULT NULL,
  `transporte_cajafria` tinyint(1) DEFAULT NULL,
  `transporte_cajafria_cantidad` int DEFAULT NULL,
  `solicitante_id` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `solicitante_id_UNIQUE` (`solicitante_id`)
) ENGINE=InnoDB AUTO_INCREMENT=40 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `equipo_transporte`
--

LOCK TABLES `equipo_transporte` WRITE;
/*!40000 ALTER TABLE `equipo_transporte` DISABLE KEYS */;
INSERT INTO `equipo_transporte` VALUES (1,0,NULL,0,NULL,0,NULL,2),(32,0,NULL,0,NULL,0,NULL,5),(34,0,NULL,0,NULL,0,NULL,6),(38,0,NULL,0,NULL,0,NULL,7);
/*!40000 ALTER TABLE `equipo_transporte` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `instalacion_hidraulica_aireacion`
--

DROP TABLE IF EXISTS `instalacion_hidraulica_aireacion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `instalacion_hidraulica_aireacion` (
  `id` int NOT NULL AUTO_INCREMENT,
  `hidraulica_bomba_agua` tinyint(1) DEFAULT NULL,
  `hidraulica_bomba_agua_cantidad` int DEFAULT NULL,
  `hidraulica_aireador` tinyint(1) DEFAULT NULL,
  `hidraulica_aireador_cantidad` int DEFAULT NULL,
  `solicitante_id` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `solicitante_id_UNIQUE` (`solicitante_id`)
) ENGINE=InnoDB AUTO_INCREMENT=39 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `instalacion_hidraulica_aireacion`
--

LOCK TABLES `instalacion_hidraulica_aireacion` WRITE;
/*!40000 ALTER TABLE `instalacion_hidraulica_aireacion` DISABLE KEYS */;
INSERT INTO `instalacion_hidraulica_aireacion` VALUES (1,0,NULL,0,NULL,2),(31,0,NULL,0,NULL,5),(33,0,NULL,0,NULL,6),(37,0,NULL,0,NULL,7);
/*!40000 ALTER TABLE `instalacion_hidraulica_aireacion` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `instrumentos_medicion`
--

DROP TABLE IF EXISTS `instrumentos_medicion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `instrumentos_medicion` (
  `id` int NOT NULL AUTO_INCREMENT,
  `instrumento_temperatura` tinyint(1) DEFAULT NULL,
  `instrumento_oxigeno` tinyint(1) DEFAULT NULL,
  `instrumento_ph` tinyint(1) DEFAULT NULL,
  `instrumento_otros` text,
  `solicitante_id` int DEFAULT NULL,
  `instrumento_temperatura_cantidad` int DEFAULT NULL,
  `instrumento_oxigeno_cantidad` int DEFAULT NULL,
  `instrumento_ph_cantidad` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `solicitante_id_UNIQUE` (`solicitante_id`)
) ENGINE=InnoDB AUTO_INCREMENT=40 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `instrumentos_medicion`
--

LOCK TABLES `instrumentos_medicion` WRITE;
/*!40000 ALTER TABLE `instrumentos_medicion` DISABLE KEYS */;
INSERT INTO `instrumentos_medicion` VALUES (1,1,1,1,NULL,2,90,2,1),(32,0,0,0,NULL,5,NULL,NULL,NULL),(34,1,0,0,NULL,6,89,NULL,NULL),(38,0,0,0,NULL,7,NULL,NULL,NULL);
/*!40000 ALTER TABLE `instrumentos_medicion` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `integrantes`
--

DROP TABLE IF EXISTS `integrantes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `integrantes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nombre_completo` varchar(150) DEFAULT NULL,
  `rfc` varchar(18) DEFAULT NULL,
  `curp` varchar(18) DEFAULT NULL,
  `sexo` int DEFAULT NULL,
  `ultimo_grado_estudio` varchar(100) DEFAULT NULL,
  `actividad_desempeña` varchar(100) DEFAULT NULL,
  `localidad` varchar(100) DEFAULT NULL,
  `municipio` varchar(100) DEFAULT NULL,
  `telefono` varchar(100) DEFAULT NULL,
  `fecha_actualizacion` datetime DEFAULT CURRENT_TIMESTAMP,
  `solicitante_id` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `solicitante_id` (`solicitante_id`),
  CONSTRAINT `integrantes_ibfk_1` FOREIGN KEY (`solicitante_id`) REFERENCES `solicitantes` (`solicitante_id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `integrantes`
--

LOCK TABLES `integrantes` WRITE;
/*!40000 ALTER TABLE `integrantes` DISABLE KEYS */;
INSERT INTO `integrantes` VALUES (9,'Janet Nochebuena Hernandez','GARM890903342','EANJ031206HNESCS10',0,'Secundaria','Empleada','Poza Rica de Hidalgo','Veracruz','2323332283','2025-09-14 23:23:15',2),(11,'Carlos Hernandez','ROJN740928L15','EANJ031206HNESCSA9',1,'Bachillerato','Ingenieria','Poza Rica de Hidalgo','Veracruz','7821968092','2025-09-25 10:13:47',6),(14,'Jesus Huerto Ochua','RARM831030828','EANJ031206HNESCSA9',1,'Universidad','Ingenieria','Poza Rica de Hidalgo','Veracruz','7821968092','2025-09-29 16:28:49',2);
/*!40000 ALTER TABLE `integrantes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `password_reset_tokens`
--

DROP TABLE IF EXISTS `password_reset_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `password_reset_tokens` (
  `id` int NOT NULL AUTO_INCREMENT,
  `email` varchar(255) NOT NULL,
  `token` varchar(255) NOT NULL,
  `expires` timestamp NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_reset_tokens`
--

LOCK TABLES `password_reset_tokens` WRITE;
/*!40000 ALTER TABLE `password_reset_tokens` DISABLE KEYS */;
INSERT INTO `password_reset_tokens` VALUES (1,'byjoshmcpeyt456@gmail.com','a60d7e9e4da9dce295ffe11f3fe9269cd61b9e3bb476ca68c56d6220b7b8cd31','2025-09-15 07:35:32');
/*!40000 ALTER TABLE `password_reset_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sistema_conservacion`
--

DROP TABLE IF EXISTS `sistema_conservacion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sistema_conservacion` (
  `id` int NOT NULL AUTO_INCREMENT,
  `conservacion_hielera` tinyint(1) DEFAULT NULL,
  `conservacion_hielera_cantidad` int DEFAULT NULL,
  `conservacion_refrigerado` tinyint(1) DEFAULT NULL,
  `conservacion_refrigerado_cantidad` int DEFAULT NULL,
  `conservacion_otros` text,
  `conservacion_otros_cantidad` int DEFAULT NULL,
  `solicitante_id` int DEFAULT NULL,
  `conservacion_cuartofrio` tinyint(1) DEFAULT NULL,
  `conservacion_cuartofrio_cantidad` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `solicitante_id_UNIQUE` (`solicitante_id`)
) ENGINE=InnoDB AUTO_INCREMENT=40 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sistema_conservacion`
--

LOCK TABLES `sistema_conservacion` WRITE;
/*!40000 ALTER TABLE `sistema_conservacion` DISABLE KEYS */;
INSERT INTO `sistema_conservacion` VALUES (1,1,NULL,0,NULL,NULL,NULL,2,0,NULL),(32,1,80,0,NULL,NULL,NULL,5,0,NULL),(34,0,NULL,0,NULL,NULL,NULL,6,0,NULL),(38,0,NULL,0,NULL,NULL,NULL,7,0,NULL);
/*!40000 ALTER TABLE `sistema_conservacion` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `solicitantes`
--

DROP TABLE IF EXISTS `solicitantes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `solicitantes` (
  `solicitante_id` int NOT NULL AUTO_INCREMENT,
  `usuario_id` int NOT NULL,
  `nombre` varchar(150) DEFAULT NULL,
  `apellido_paterno` varchar(100) DEFAULT NULL,
  `apellido_materno` varchar(100) DEFAULT NULL,
  `rfc` varchar(13) DEFAULT NULL,
  `curp` varchar(18) DEFAULT NULL,
  `telefono` varchar(10) DEFAULT NULL,
  `correo_electronico` varchar(50) DEFAULT NULL,
  `nombre_representante_legal` varchar(100) DEFAULT NULL,
  `actividad` varchar(100) DEFAULT NULL,
  `entidad_federativa` varchar(100) DEFAULT NULL,
  `municipio` varchar(100) DEFAULT NULL,
  `localidad` varchar(100) DEFAULT NULL,
  `colonia` varchar(15) DEFAULT NULL,
  `codigo_postal` varchar(100) DEFAULT NULL,
  `calle` varchar(150) DEFAULT NULL,
  `no_exterior` varchar(150) DEFAULT NULL,
  `no_interior` varchar(50) DEFAULT NULL,
  `fecha_actualizacion` datetime DEFAULT CURRENT_TIMESTAMP,
  `anexo1_completo` tinyint(1) NOT NULL DEFAULT '0',
  `numero_integrantes` int DEFAULT NULL,
  PRIMARY KEY (`solicitante_id`),
  UNIQUE KEY `usuario_id_UNIQUE` (`usuario_id`),
  CONSTRAINT `fk_solicitantes_usuarios` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `solicitantes`
--

LOCK TABLES `solicitantes` WRITE;
/*!40000 ALTER TABLE `solicitantes` DISABLE KEYS */;
INSERT INTO `solicitantes` VALUES (2,6,'Miguel Gil','Herrera Nochebuena','Hernandez','RARM831030828','EANJ031206HNESCSA7','2321331550','byjoshmcpeyt456@gmail.com','Jesus Antonio Mejia','pesca','Mexico','Veracruz','POZA RICA DE HIDALGO','Mecatepec','93600','MECATEPEC #101 BLVD ADOLFO RUIZ CORTINES','90','23','2025-09-10 17:13:32',1,32),(3,7,NULL,NULL,NULL,NULL,'EANJ031205HNESCSA6',NULL,'byjoshmcpeyt900@gmail.com',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2025-09-09 17:09:02',0,NULL),(4,8,'Laukaby','Hernandez','Perez','RARM831030828','EANJ031206HNESCSA2','7821968092','gdiasix@gmail.com','Jesus Antonio Mejia','acuacultura','Mexico','Veracruz','Poza Rica de Hidalgo','Mecatepec','93300','MECATEPEC #101 BLVD ADOLFO RUIZ CORTINEZ','2613','1','2025-09-15 01:25:21',1,3),(5,9,'Joshua Emmanuel','Estrada','Nochebuena','ROJN740928L15','EANJ031206HNESCS33','7821968092','sunix473@gmail.com','Jesus Antonio Mejia','ambas','Mexico','Veracruz','POZA RICA DE HIDALGO','Mecatepez','93600','MECATEPEC #101 BLVD ADOLFO RUIZ CORTINEZ','2613','9','2025-09-20 18:43:14',1,3),(6,10,'JANET','ESTRADA','NOCHEBUENA HERNANDEZ','RODF9307277N1','EANJ031206HNESCS44','7821968092','janetnochebuena91@gmail.com','Jesus Antonio Mejia','pesca','Mexico','Veracruz','Poza Rica de Hidalgo','Ruiz Cortinez','93300','MECATEPEC #101 BLVD ADOLFO RUIZ CORTINEZ','2613','1','2025-09-25 10:10:08',1,4),(7,11,'Brayan','Perez','Ortinez','GARM890903346','EANJ031206HNESCS99','7821968092','diazfaker88@gmail.com','Jesus Antonio Mejia','ambas','Mexico','Veracruz','Poza Rica de Hidalgo','Ruiz Cortinez','93300','MECATEPEC #101 BLVD ADOLFO RUIZ CORTINEZ','2613','4','2025-09-25 11:31:48',1,6);
/*!40000 ALTER TABLE `solicitantes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tipo_estanques`
--

DROP TABLE IF EXISTS `tipo_estanques`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tipo_estanques` (
  `id` int NOT NULL AUTO_INCREMENT,
  `solicitante_id` int DEFAULT NULL,
  `rustico` tinyint(1) DEFAULT '0',
  `rustico_cantidad` int DEFAULT NULL,
  `rustico_dimensiones` varchar(255) DEFAULT NULL,
  `geomembrana` tinyint(1) DEFAULT '0',
  `geomembrana_cantidad` int DEFAULT NULL,
  `geomembrana_dimensiones` varchar(255) DEFAULT NULL,
  `concreto` tinyint(1) DEFAULT '0',
  `concreto_cantidad` int DEFAULT NULL,
  `concreto_dimensiones` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `solicitante_id_UNIQUE` (`solicitante_id`)
) ENGINE=InnoDB AUTO_INCREMENT=40 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tipo_estanques`
--

LOCK TABLES `tipo_estanques` WRITE;
/*!40000 ALTER TABLE `tipo_estanques` DISABLE KEYS */;
INSERT INTO `tipo_estanques` VALUES (1,2,1,90,'90x90',1,10,'10x10',1,82,'5x5'),(32,5,1,89,'300x300',1,12,NULL,0,NULL,NULL),(34,6,0,90,'200x200',1,4,'90x90',1,3,'10x10'),(38,7,1,900,NULL,1,70,'200x200',0,NULL,NULL);
/*!40000 ALTER TABLE `tipo_estanques` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `unidad_pesquera`
--

DROP TABLE IF EXISTS `unidad_pesquera`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `unidad_pesquera` (
  `id` int NOT NULL AUTO_INCREMENT,
  `solicitante_id` int DEFAULT NULL,
  `emb_madera` tinyint(1) DEFAULT NULL,
  `emb_madera_cantidad` int DEFAULT NULL,
  `emb_fibra` tinyint(1) DEFAULT NULL,
  `emb_fibra_cantidad` int DEFAULT NULL,
  `emb_metal` tinyint(1) DEFAULT NULL,
  `emb_metal_cantidad` int DEFAULT NULL,
  `motores` tinyint(1) DEFAULT NULL,
  `motores_cantidad` int DEFAULT NULL,
  `cons_hielera` tinyint(1) DEFAULT NULL,
  `cons_hielera_cantidad` int DEFAULT NULL,
  `cons_refrigerador` tinyint(1) DEFAULT NULL,
  `cons_refrigerador_cantidad` int DEFAULT NULL,
  `cons_cuartofrio` tinyint(1) DEFAULT NULL,
  `cons_cuartofrio_cantidad` int DEFAULT NULL,
  `trans_camioneta` tinyint(1) DEFAULT NULL,
  `trans_camioneta_cantidad` int DEFAULT NULL,
  `trans_cajafria` tinyint(1) DEFAULT NULL,
  `trans_cajafria_cantidad` int DEFAULT NULL,
  `trans_camion` tinyint(1) DEFAULT NULL,
  `trans_camion_cantidad` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `solicitante_id_idx` (`solicitante_id`),
  CONSTRAINT `fk_unidad_pesquera_solicitante` FOREIGN KEY (`solicitante_id`) REFERENCES `solicitantes` (`solicitante_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `unidad_pesquera`
--

LOCK TABLES `unidad_pesquera` WRITE;
/*!40000 ALTER TABLE `unidad_pesquera` DISABLE KEYS */;
INSERT INTO `unidad_pesquera` VALUES (1,2,1,100,1,0,0,0,0,0,0,10,1,200,0,0,0,0,0,0,0,0),(2,5,1,33,0,0,0,0,0,0,1,22,0,0,0,0,0,0,0,0,1,900),(3,6,1,90,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0);
/*!40000 ALTER TABLE `unidad_pesquera` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `unidad_produccion`
--

DROP TABLE IF EXISTS `unidad_produccion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `unidad_produccion` (
  `id` int NOT NULL AUTO_INCREMENT,
  `solicitante_id` int DEFAULT NULL,
  `tipo_estanque_id` int DEFAULT NULL,
  `instrumento_id` int DEFAULT NULL,
  `sistema_conservacion_id` int DEFAULT NULL,
  `equipo_transporte_id` int DEFAULT NULL,
  `embarcacion_id` int DEFAULT NULL,
  `instalacion_id` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `solicitante_id_UNIQUE` (`solicitante_id`),
  KEY `fk_unidad_produccion_estanques` (`tipo_estanque_id`),
  KEY `fk_unidad_produccion_instrumentos` (`instrumento_id`),
  KEY `fk_unidad_produccion_conservacion` (`sistema_conservacion_id`),
  KEY `fk_unidad_produccion_transporte` (`equipo_transporte_id`),
  KEY `fk_unidad_produccion_embarcaciones_acu` (`embarcacion_id`),
  KEY `fk_unidad_produccion_hidraulica` (`instalacion_id`),
  CONSTRAINT `fk_unidad_produccion_conservacion` FOREIGN KEY (`sistema_conservacion_id`) REFERENCES `sistema_conservacion` (`id`),
  CONSTRAINT `fk_unidad_produccion_embarcaciones_acu` FOREIGN KEY (`embarcacion_id`) REFERENCES `embarcaciones` (`id`),
  CONSTRAINT `fk_unidad_produccion_estanques` FOREIGN KEY (`tipo_estanque_id`) REFERENCES `tipo_estanques` (`id`),
  CONSTRAINT `fk_unidad_produccion_hidraulica` FOREIGN KEY (`instalacion_id`) REFERENCES `instalacion_hidraulica_aireacion` (`id`),
  CONSTRAINT `fk_unidad_produccion_instrumentos` FOREIGN KEY (`instrumento_id`) REFERENCES `instrumentos_medicion` (`id`),
  CONSTRAINT `fk_unidad_produccion_solicitante` FOREIGN KEY (`solicitante_id`) REFERENCES `solicitantes` (`solicitante_id`) ON DELETE CASCADE,
  CONSTRAINT `fk_unidad_produccion_transporte` FOREIGN KEY (`equipo_transporte_id`) REFERENCES `equipo_transporte` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=39 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `unidad_produccion`
--

LOCK TABLES `unidad_produccion` WRITE;
/*!40000 ALTER TABLE `unidad_produccion` DISABLE KEYS */;
INSERT INTO `unidad_produccion` VALUES (1,2,NULL,NULL,NULL,NULL,NULL,NULL),(31,5,NULL,NULL,NULL,NULL,NULL,NULL),(33,6,NULL,NULL,NULL,NULL,NULL,NULL),(37,7,NULL,NULL,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `unidad_produccion` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usuarios`
--

DROP TABLE IF EXISTS `usuarios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `usuarios` (
  `id` int NOT NULL AUTO_INCREMENT,
  `curp` varchar(18) NOT NULL,
  `email` varchar(100) DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `creado_en` datetime DEFAULT CURRENT_TIMESTAMP,
  `token_restablecimiento` varchar(100) DEFAULT NULL,
  `solicitante_id` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `curp_UNIQUE` (`curp`),
  KEY `fk_usuarios_solicitantes` (`solicitante_id`),
  CONSTRAINT `fk_usuarios_solicitantes` FOREIGN KEY (`solicitante_id`) REFERENCES `solicitantes` (`solicitante_id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usuarios`
--

LOCK TABLES `usuarios` WRITE;
/*!40000 ALTER TABLE `usuarios` DISABLE KEYS */;
INSERT INTO `usuarios` VALUES (6,'EANJ031206HNESCSA7','byjoshmcpeyt456@gmail.com','$2b$10$KndhACCv29g1PNqu8HWWBOhsFebRk6eGG.DU2SqBYNXOsAHaIVq7i','2025-09-09 16:21:06',NULL,NULL),(7,'EANJ031205HNESCSA6','byjoshmcpeyt900@gmail.com','$2b$10$MqebDSGhp0yN4j.gC1DljO7iBGHe.iE/0TpJpgttvL773/2pPBSdC','2025-09-09 17:09:02',NULL,NULL),(8,'EANJ031206HNESCSA2','gdiasix@gmail.com','$2b$10$3f93.9I5O2jlqbVzkQHFzuD.ZAx675RAUadswJJLsGO0wyTXm7a.O','2025-09-15 01:25:21',NULL,NULL),(9,'EANJ031206HNESCS33','sunix473@gmail.com','$2b$10$OSEphbkdYIY/CQGUhkaOQuGTzU7JpjhsfnWnsQ2JeqYesRdvgWk1i','2025-09-20 18:43:14',NULL,NULL),(10,'EANJ031206HNESCS44','janetnochebuena91@gmail.com','$2b$10$/296GqPTomTrIH41xnZ7VOmIIfEiXbh3RFMk4V3t7/CFsKr/atPYi','2025-09-25 10:10:08',NULL,NULL),(11,'EANJ031206HNESCS99','diazfaker88@gmail.com','$2b$10$X67DnKiff3bTSmPyG34DLuq/tgzwgWpfcMHbjMYoTYJflhEKo7I0C','2025-09-25 11:31:48',NULL,NULL);
/*!40000 ALTER TABLE `usuarios` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-09-29 18:02:53
