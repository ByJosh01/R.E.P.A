document.addEventListener('DOMContentLoaded', () => {

    // ### LÓGICA PARA MODO OSCURO ###
    const themeToggle = document.getElementById('theme-toggle');
    const body = document.body;
    if (themeToggle) {
        const themeIcon = themeToggle.querySelector('i');
        const applyTheme = (theme) => {
            if (theme === 'dark') {
                body.classList.add('dark-mode');
                if (themeIcon) {
                    themeIcon.classList.remove('fa-moon');
                    themeIcon.classList.add('fa-sun');
                }
                localStorage.setItem('theme', 'dark');
            } else {
                body.classList.remove('dark-mode');
                if (themeIcon) {
                    themeIcon.classList.remove('fa-sun');
                    themeIcon.classList.add('fa-moon');
                }
                localStorage.setItem('theme', 'light');
            }
        };
        const savedTheme = localStorage.getItem('theme') || 'light';
        applyTheme(savedTheme);
        themeToggle.addEventListener('click', () => {
            const currentTheme = body.classList.contains('dark-mode') ? 'light' : 'dark';
            applyTheme(currentTheme);
        });
    }
    
    // ### ANIMACIÓN DE ENTRADA (AÑADIDA) ###
    const mainContent = document.querySelector('.main-content');
    if (mainContent) {
        mainContent.classList.add('visible');
    }

    // --- PROTECCIÓN DE RUTA ---
    const currentUser = JSON.parse(sessionStorage.getItem('currentUser'));
    if (!currentUser) {
        alert('Acceso denegado. Por favor, inicie sesión.');
        window.location.href = '/home.html';
        return;
    }

    // Cargar datos del usuario
    document.getElementById('user-curp').textContent = currentUser.curp;
    document.getElementById('user-email').textContent = currentUser.email;

    // Acordeón de Cambio de Contraseña
    const accordion = document.getElementById('password-accordion');
    if (accordion) {
        accordion.querySelector('.accordion-header').addEventListener('click', () => {
            accordion.classList.toggle('active');
        });
    }

    // Formulario de Cambio de Contraseña (aún no conectado al backend)
    const changePasswordForm = document.getElementById('change-password-form');
    if (changePasswordForm) {
        changePasswordForm.addEventListener('submit', (e) => {
            e.preventDefault();
            alert('Funcionalidad en desarrollo. Se requiere conectar al backend.');
        });
    }

    // Botón de Cerrar Sesión
    const logoutBtn = document.getElementById('logout-btn');
    if (logoutBtn) {
        logoutBtn.addEventListener('click', () => {
            sessionStorage.removeItem('currentUser');
            alert('Has cerrado la sesión.');
            window.location.href = '/home.html';
        });
    }
});